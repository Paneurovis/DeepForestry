<h1> Ensemble Deep Learning For Stock Price Prediction </h1>

<p>These are the project files for my third year project with the same title as above. Completed as part of my third year studying for an MSc (Hons) Computer Science (with Industrial Experience) at Lancaster University. </p>

<p>The files are for use in within a Jupyter Notebook, the dataset provided originates from the the following paper titled: <a href="https://www.researchgate.net/publication/338138728_DP-LSTM_Differential_Privacy-inspired_LSTM_for_Stock_Prediction_Using_Financial_News">DP-LSTM: Differential Privacyinspired LSTM for Stock Prediction Using Financial News</a> </p>

